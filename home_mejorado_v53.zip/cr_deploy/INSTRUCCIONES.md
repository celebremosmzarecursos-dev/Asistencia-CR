# 📲 Registro de Asistencia CR — Guía de publicación e instalación

Esta guía te deja la app **con login (usuario y contraseña)** y **lista para instalarse en el celular de los líderes**, sin que quede visible/abierta para cualquiera. Los datos que ya cargaste **NO se pierden**: siguen en tu base de datos de Firebase.

Tienes que hacer 3 cosas, una sola vez:
1. Activar el inicio de sesión y crear las cuentas de los líderes (empezando por el **coordinador**).
2. Proteger la base de datos para que solo entren usuarios con sesión.
3. Publicar la app en internet (Firebase Hosting) e instalarla en los celulares.

Además, la app ahora tiene **5 roles con distintos permisos** (coordinador, líder de grupo abierto, líder de grupo cerrado, líder de bienvenida y Ministerio — Solo lectura). El coordinador asigna los roles desde el panel **🛡️ Usuarios** dentro de la app. Revisa la sección **"Roles y permisos"** más abajo.

---

## 1) Activar inicio de sesión y crear las cuentas de los líderes

1. Entra a la consola: **https://console.firebase.google.com/** y abre el proyecto **asistencia-cr-alameda**.
2. En el menú izquierdo: **Compilación → Authentication** (Autenticación) → botón **Comenzar**.
3. En la pestaña **Sign-in method** (Método de acceso) → elige **Correo electrónico/Contraseña** → **Habilitar** → **Guardar**.
4. Ve a la pestaña **Users** (Usuarios) → **Agregar usuario**. **Lo primero:** crea la cuenta del **coordinador (dueño)** con el correo **`celebremosmdz@gmail.com`** y una contraseña. Este correo siempre tiene acceso total y no puede quedar bloqueado.
5. Luego crea una cuenta (correo + contraseña) por cada líder. Por ejemplo:

   | Correo                       | Contraseña (inicial) | Rol que tendrá (se asigna después) |
   |------------------------------|----------------------|------------------------------------|
   | celebremosmdz@gmail.com      | (la que elijas)      | Coordinador (automático)           |
   | lider1@celebremoscr.app      | Cambiar123           | Líder de Grupo Abierto             |
   | lider2@celebremoscr.app      | Cambiar123           | Líder de Grupo Cerrado             |
   | lider3@celebremoscr.app      | Cambiar123           | Líder de Bienvenida                |
   | consulta@otroministerio.org  | Cambiar123           | Ministerio — Solo lectura          |

   > 💡 Los correos **no necesitan existir de verdad** (no se envía ningún email). Sirven solo como nombre de usuario. Puedes usar los correos reales de los líderes si prefieres.
   > 🔒 Dales a cada líder su correo y contraseña. Solo quien tenga una cuenta creada aquí podrá entrar a la app.
   > ⚠️ **Dos pasos por líder:** crear la cuenta aquí (paso 5) **y** asignarle un rol en el panel **🛡️ Usuarios** de la app (ver sección "Roles y permisos"). Si solo creas la cuenta pero no le asignas rol, al entrar verá el mensaje *"Tu cuenta no tiene permisos asignados todavía"*.

---

## 2) Proteger la base de datos (roles y Portal del Participante)

Para que nadie sin cuenta pueda leer/escribir los datos:

1. En el menú: **Compilación → Realtime Database**.
2. Pestaña **Reglas (Rules)**.
3. Abre `database.rules.json`, copia **todo** su contenido, reemplaza las reglas del editor y pulsa **Publicar**.

También puedes publicarlas desde una terminal abierta en esta carpeta:

```bash
firebase deploy --only database
```

**Qué hacen estas reglas:**
- Cada líder puede acceder solamente a los datos correspondientes a su rol.
- Cada líder consulta únicamente su propia asignación en **`usuarios`**; solo el coordinador puede ver y administrar el listado completo.
- El Portal del Participante guarda las propuestas en **`portal_participantes/{uid}`**. Cada participante solo puede leer y modificar su propio registro.
- El acceso del participante exige un correo verificado mediante el enlace de Firebase.
- El participante no puede escribir en `participantes`, `asistencias`, `grupos_pasos`, `usuarios` ni estadísticas.
- Solo el coordinador puede habilitar correos y confirmar Mentor y los tres Compañeros de Rendición de Cuentas en la ficha oficial.
- Los roles se guardan con la clave del correo en minúsculas y con los puntos `.` cambiados por comas `,` (por ejemplo `lider1@correo,com`). La app y las reglas usan exactamente el mismo formato.
- La app además esconde y bloquea las secciones según el rol; estas reglas son una capa extra de seguridad para el nodo de usuarios.

> ✅ A partir de aquí, la app solo funciona después de iniciar sesión. Los datos ya cargados siguen intactos.

---

## 🛡️ Roles y permisos

La app tiene **5 roles**. El coordinador los asigna desde el panel **🛡️ Usuarios** (visible solo para él).

| Rol | Qué puede hacer |
|-----|-----------------|
| **Coordinador** | Ve y modifica **todo**: participantes, asistencias de todos los grupos (abierto y de pasos), reportes/estadísticas, correcciones (borrar registros) y el **panel de Usuarios**. |
| **Líder de Grupo Abierto** | Ve una única planilla de su sector: **solo Varones** o **solo Mujeres**. Carga la asistencia de los viernes y puede actualizar únicamente nombre, celular, estado civil e hijos de esos participantes. El área de recuperación se conserva para las estadísticas, pero no divide la planilla semanal. No ve etiquetas internas, grupos de pasos, reportes ni el panel de usuarios, y no puede borrar registros. |
| **Líder de Grupo Cerrado** (Grupo de Pasos) | Solo ve y carga la asistencia de **el/los grupo(s) de pasos que se le asignaron**. No ve otros grupos ni el panel de usuarios. |
| **Líder de Bienvenida** | Solo puede registrar **nuevos participantes** (formulario "Nuevo participante"). Nada más. |
| **Ministerio — Solo lectura** | Consulta la lista básica de participantes y todas las planillas de asistencia. No ve datos sensibles ni puede editar, marcar, suspender, borrar, imprimir o acceder a paneles administrativos. |

### Cómo asignar roles (panel 🛡️ Usuarios)

1. Inicia sesión con el **coordinador** (`celebremosmdz@gmail.com`).
2. Entra a la pestaña **🛡️ Usuarios** del menú superior.
3. En **"Agregar / asignar usuario"**: escribe el **correo** del líder (el mismo que creaste en Firebase Console) y elige su **rol**. Si es **Líder de Grupo Abierto**, selecciona solamente Varones o Mujeres. Si es **Líder de Grupo Cerrado**, marca el/los **grupo(s) de pasos** que lidera. Opcionalmente escribe su nombre.
4. Pulsa **💾 Agregar usuario**. Puedes **✏️ Editar** o **🗑️ Quitar** un usuario cuando quieras.

> 🔑 **Recuerda los dos pasos por líder:**
> 1. **En la app (panel Usuarios):** el coordinador le asigna el rol (y grupo).
> 2. **En Firebase Console → Authentication → Users:** debe existir una cuenta (correo + contraseña) con ese mismo correo para que la persona pueda iniciar sesión.
>
> Si falta el paso 1, el líder entra pero verá *"Tu cuenta no tiene permisos asignados todavía"*. Si falta el paso 2, no podrá iniciar sesión.
> Las cuentas que aparecen en Firebase **Authentication → Users** no se copian automáticamente al panel **Usuarios** de la aplicación. Deben completarse ambos pasos usando exactamente el mismo correo.
>
> El coordinador (`celebremosmdz@gmail.com`) **siempre** es Coordinador aunque el panel esté vacío, así nunca queda bloqueado.

### Mujeres: Adicciones ahora y división futura con Enojo

- Las participantes de este sector comienzan en **Adicciones**.
- **Enojo** aparece como un área separada para que el coordinador pueda trasladar participantes una por una más adelante desde **Editar participante → Grupo Abierto**.
- En **Coordinador → Usuarios** hay una tarjeta de organización. Si detecta la denominación anterior **Ira Compulsiva** o una denominación combinada, pulsa una sola vez **Consolidar denominaciones anteriores en Adicciones**. La acción pide confirmación y no borra asistencias.
- Cuando una participante cambia entre Adicciones y Enojo, su historial de viernes la acompaña.

### Faltas de viernes y etiquetas de Grupos de Pasos

Las faltas de los viernes solo generan alerta o abandono mientras la persona tenga una **participación activa en un Grupo de Pasos**. Al completar, abandonar o quedar fuera por tres faltas, el ciclo se cierra: desaparecen las etiquetas activas y las inasistencias posteriores de los viernes dejan de producir alertas. La asistencia de los viernes continúa registrándose y sigue disponible para estadísticas.

### Participaciones repetidas en Grupos de Pasos

- Cada ingreso a Pasos se guarda como una participación independiente con grupo, rol, fecha de inicio, fecha de cierre, resultado y asistencia.
- Al terminar todo un grupo, sus integrantes quedan como **Completó**, salen de la planilla activa y conservan el ciclo en el historial.
- El coordinador también puede cerrar una participación individual como **Completó** o **Abandonó** desde la ficha de la persona.
- La tercera falta en una Guía cierra solamente ese ciclo como **Fuera por faltas**.
- Si la persona regresa, edita su ficha, marca que participa en Pasos, selecciona el grupo y coloca la nueva fecha de inicio. Se crea un ciclo limpio sin borrar los anteriores.
- Los datos anteriores a esta versión se reconocen automáticamente; si ya hay asistencia en varios grupos, se reconstruye un ciclo histórico por cada grupo identificado.

---

## 3) Publicar la app e instalarla en los celulares

### Opción A — Rápida (recomendada), desde tu computadora

Necesitas Node.js instalado (https://nodejs.org). Luego, en una terminal:

```bash
# 1. Instalar la herramienta de Firebase (una sola vez)
npm install -g firebase-tools

# 2. Iniciar sesión con tu cuenta de Google (la del proyecto)
firebase login

# 3. Entrar a esta carpeta (donde está index.html)
cd ruta/a/esta/carpeta   # la carpeta que contiene index.html y firebase.json

# 4. Publicar página y reglas
firebase deploy --only hosting,database
```

Al terminar te dará una dirección tipo:
**https://asistencia-cr-alameda.web.app**

Esa es la dirección de tu app. Compártela SOLO con los líderes.

> ℹ️ La dirección técnicamente es pública, pero **sin usuario y contraseña nadie puede ver ni cargar datos**. Solo los líderes con cuenta pueden entrar.

### Instalar en el celular (Android)
1. Abre la dirección (**https://asistencia-cr-alameda.web.app**) en **Chrome**.
2. Aparecerá el botón **📲 Instalar app** (abajo a la derecha), o el menú **⋮ → Instalar aplicación / Agregar a pantalla de inicio**.
3. Queda como una app normal, con su ícono, en la pantalla del celular.
4. En **Asistencias**, puedes girar el teléfono en horizontal o pulsar **Ampliar planilla** para ver los nombres y las fechas con más comodidad.

### Instalar en el celular (iPhone)
1. Abre la dirección en **Safari**.
2. Toca el botón **Compartir** (cuadro con flecha) → **Agregar a pantalla de inicio**.
3. Queda como una app con su ícono.
4. En **Asistencias**, gira el teléfono en horizontal para disponer de más espacio para marcar las fechas.

---

## Contenido de esta carpeta

- `index.html` — La aplicación (con login y soporte de instalación).
- `participante.html` — Portal privado para Mentor y tres Compañeros de Rendición de Cuentas.
- `manifest.json` — Datos de la app para poder instalarla (nombre, íconos, colores).
- `sw.js` — Service worker (permite instalarla y que abra más rápido).
- `icons/` — Íconos de la app.
- `assets/` — Identidad visual de Lumina Digital Lab para el pie institucional.
- `firebase.json` — Configuración de publicación (Firebase Hosting).
- `.firebaserc` — Indica el proyecto (`asistencia-cr-alameda`).
- `database.rules.json` — Reglas de seguridad de la base de datos.

---

## Preguntas frecuentes

**¿Se pierden los datos ya cargados?** No. El login y la publicación no tocan tus datos; siguen en Realtime Database.

**¿Puedo agregar o quitar líderes después?** Sí. Vuelve a *Authentication → Users* y agrega o elimina cuentas cuando quieras.

**¿Cómo cambio una contraseña?** En *Authentication → Users*, en los tres puntos de cada usuario, **Restablecer contraseña**.

**¿Y si un líder olvida cerrar sesión?** Dentro de la app hay un botón **🔓 Salir** arriba a la derecha.

**¿Necesito volver a publicar cuando cambie algo?** Para esta versión publica página y reglas juntas con `firebase deploy --only hosting,database`.

---

## Portal del Participante — activación única

1. En Firebase Console entra a **Security → Authentication → Sign-in method**.
2. Abre **Email/Password**, habilita **Email/Password** y también **Email link (passwordless sign-in)**. Guarda los cambios.
3. En **Authentication → Settings → Authorized domains**, comprueba que esté el dominio donde publicaste la aplicación. Firebase Hosting normalmente usa `asistencia-cr-alameda.web.app` y `asistencia-cr-alameda.firebaseapp.com`. Si utilizas un dominio propio, agrégalo.
4. Publica esta versión con `firebase deploy --only hosting,database`.
5. Entra como Coordinador, abre un participante y escribe un correo real en **Acceso al Portal del Participante**.
6. En **Usuarios → Portal del Participante**, copia el enlace y envíaselo. El participante solicita su enlace de acceso desde ese portal.
7. Cuando complete Mentor y sus tres Compañeros de Rendición de Cuentas, aparecerá como **Pendiente**. Pulsa **Confirmar datos** para incorporarlos a su ficha oficial.

Los participantes sin correo continúan siendo cargados normalmente por el coordinador.

La aplicación y el portal incluyen el pie: **Aplicación creada en 2026 por Lumina Digital Lab — © 2026 Lumina Digital Lab · Todos los derechos reservados.**

---

## Períodos de lecciones en Grupos de Pasos — Versión 28

En un **Grupo de Pasos** activo, abre **Ver detalles**. En el panel de avance,
selecciona la guía y lección, completa **Lección desde** y **Lección hasta** y
pulsa **Guardar período de esta lección**. La planilla mostrará `L1`, `L2`,
etc. en cada fecha y guardará la asistencia con la lección correspondiente.

Los períodos pueden corregirse desde **Períodos de las lecciones**. Esta acción
no borra ni modifica asistencias ya registradas.

Para publicar esta mejora:

```bash
firebase deploy --only hosting
```
